﻿using System.Windows;

namespace RadioButton
{
    /// <summary>
    /// Interaction logic for RadioButtonWindow.xaml
    /// </summary>
    public partial class RadioButtonWindow : Window
    {
        public RadioButtonWindow()
        {
            InitializeComponent();
        }
    }
}
