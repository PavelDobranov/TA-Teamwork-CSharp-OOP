﻿using System.Windows;

namespace RichTextBox
{
    /// <summary>
    /// Interaction logic for RichTextBoxWindow.xaml
    /// </summary>
    public partial class RichTextBoxWindow : Window
    {
        public RichTextBoxWindow()
        {
            InitializeComponent();
        }
    }
}
