﻿using System.Windows;

namespace GroupBoxAndExpander
{
    /// <summary>
    /// Interaction logic for GroupBoxWindow.xaml
    /// </summary>
    public partial class GroupBoxWindow : Window
    {
        public GroupBoxWindow()
        {
            InitializeComponent();
        }
    }
}
