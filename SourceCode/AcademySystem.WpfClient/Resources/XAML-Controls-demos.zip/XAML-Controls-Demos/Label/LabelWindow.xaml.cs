﻿using System.Windows;

namespace Label
{
    /// <summary>
    /// Interaction logic for LabelWindow.xaml
    /// </summary>
    public partial class LabelWindow : Window
    {
        public LabelWindow()
        {
            InitializeComponent();
        }
    }
}
