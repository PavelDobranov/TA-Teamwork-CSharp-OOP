﻿using System.Windows;

namespace ToolBar
{
    /// <summary>
    /// Interaction logic for ToolBarWindow.xaml
    /// </summary>
    public partial class ToolBarWindow : Window
    {
        public ToolBarWindow()
        {
            InitializeComponent();
        }
    }
}
